const authResultSchema = {
  type: 'object',
  properties: {
    token: { type: 'string' },
    user: {
      type: 'object',
      properties: {
        id: { type: 'string' },
        email: { type: 'string' },
        name: { type: 'string' }
      }
    }
  }
};

export const signupSchema = {
  tags: ['Auth'],
  summary: 'Sign up',
  body: {
    type: 'object',
    additionalProperties: false,
    required: ['email', 'name', 'password'],
    properties: {
      email: { type: 'string', format: 'email' },
      name: { type: 'string', minLength: 2 },
      phone: { type: 'string', minLength: 10, maxLength: 15 },
      password: { type: 'string', minLength: 8 }
    }
  },
  response: {
    201: authResultSchema
  }
};

export const loginSchema = {
  tags: ['Auth'],
  summary: 'Login',
  body: {
    type: 'object',
    additionalProperties: false,
    required: ['email', 'password'],
    properties: {
      email: { type: 'string', format: 'email' },
      password: { type: 'string' }
    }
  },
  response: {
    200: authResultSchema
  }
};

export const verifyUserSchema = {
  tags: ['Auth'],
  summary: 'Verify user by email and phone',
  querystring: {
    type: 'object',
    additionalProperties: false,
    required: ['email', 'phone'],
    properties: {
      email: { type: 'string', format: 'email' },
      phone: { type: 'string', minLength: 10, maxLength: 15 }
    }
  },
  headers: {
    type: 'object',
    required: ['reset_key'],
    properties: {
      reset_key: { type: 'string' }
    }
  },
  response: {
    200: {
      type: 'object',
      properties: {
        reset_key: { type: 'string' }
      }
    }
  }
};
